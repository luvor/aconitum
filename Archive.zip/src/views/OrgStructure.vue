<template>
  <div>
    <OrgStructureHeader title="Организационная структура" />
    <div v-if="table" class="OrgStructure">
      <OrgStructureTable :data="data" />
    </div>
    <div v-else class="OrgStructure">
      <OrgStructureTableDiv :data="data" />
    </div>
  </div>
</template>
<script>
import OrgStructureHeader from "@/components/orgStructure/OrgStructureHeader.vue";
import OrgStructureTable from "@/components/orgStructure/Table/OrgStructureTable.vue";
import OrgStructureTableDiv from "@/components/orgStructure/Div/OrgStructureTableDiv.vue";

import { data } from "@/mock.js";
export default {
  name: "OrgStructure",
  data() {
    return {
      data: data,
      table: false,
    };
  },
  components: {
    OrgStructureHeader,
    OrgStructureTable,
    OrgStructureTableDiv,
  },
};
</script>
