<template>
  <div class="OrgStructureTableDiv noselect">
    <div class="OrgStructureTableDiv__header">
      <div class="OrgStructureTableDiv__headerItem"></div>
      <div class="OrgStructureTableDiv__headerItem">Общее количество</div>
      <div class="OrgStructureTableDiv__headerItem">Фактическое количество</div>
      <div class="OrgStructureTableDiv__headerItem">Действия</div>
    </div>
    <OrgStructureTableItemDiv
      v-for="(v, n) in data"
      :key="n"
      :id="n"
      :name="n"
      :self="v['Данные']"
      :children="v['Подразделения']"
    />
  </div>
</template>
<script>
import OrgStructureTableItemDiv from "@/components/orgStructure/Div/OrgStructureTableItemDiv.vue";
export default {
  name: "OrgStructureTableDiv",
  props: {
    data: {
      type: Object,
      default: null,
    },
  },
  components: {
    OrgStructureTableItemDiv,
  },
  mounted() {
    // console.log(this.data);
  },
};
</script>
<style lang="scss">
.OrgStructureTableDiv {
  margin-top: 1rem;
  width: 100%;
  &__header {
    display: flex;
    justify-content: flex-end;
    background-color: #2d3e50;
    color: #fff;
    text-align: left;
    &Item {
      min-width: fit-content;
      padding: 15px 2em;
      text-align: left;
      border-right: 1px solid #fff;
    }
  }
}
</style>
