<template>
  <table class="OrgStructureTable noselect">
    <thead>
      <tr class="OrgStructureTable__header">
        <th class="OrgStructureTable__headerItem"></th>
        <th class="OrgStructureTable__headerItem">Общее количество</th>
        <th class="OrgStructureTable__headerItem">Фактическое количество</th>
        <th class="OrgStructureTable__headerItem">Действия</th>
      </tr>
    </thead>
    <tbody>
      <OrgStructureTableItem
        v-for="(v, n) in data"
        :key="n"
        :id="n"
        :name="n"
        :self="v['Данные']"
        :children="v['Подразделения']"
      />
    </tbody>
  </table>
</template>
<script>
import OrgStructureTableItem from "@/components/orgStructure/Table/OrgStructureTableItem.vue";
export default {
  name: "OrgStructureTable",
  props: {
    data: {
      type: Object,
      default: null,
    },
  },
  components: {
    OrgStructureTableItem,
  },
  mounted() {
    // console.log(this.data);
  },
};
</script>
<style lang="scss">
.OrgStructureTable {
  margin-top: 1rem;
  width: 100%;
  &__header {
    display: flex;
    justify-content: flex-end;
    background-color: #2d3e50;
    color: #fff;
    text-align: left;
    &Item {
      min-width: fit-content;
      padding: 15px 2em;
      text-align: left;
      border-right: 1px solid #fff;
    }
  }
}
</style>
